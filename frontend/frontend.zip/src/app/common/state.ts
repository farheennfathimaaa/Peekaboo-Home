export class State {
    name:string;
    id:number;
}

